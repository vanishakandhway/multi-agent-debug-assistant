import React, { useState, useRef } from 'react'

const PRESETS = [
  {
    label: 'average() gives wrong result',
    text: 'test_average fails: average([1,2,3,4]) returns 2 instead of 2.5',
  },
  {
    label: 'remove_duplicates() broken',
    text: 'test_remove_duplicates fails: remove_duplicates([1,2,2,3,1]) returns [] instead of [1,2,3]',
  },
  {
    label: 'find_max_below() off-by-one',
    text: 'test_find_max_below fails: find_max_below([1,5,9,10], 10) returns 10 instead of 9',
  },
]

const AGENT_COLORS = {
  planner: '#6366f1',
  retriever: '#0ea5e9',
  diagnoser: '#f59e0b',
  fixer: '#ef4444',
  verifier: '#22c55e',
}

const WS_URL = 'ws://localhost:8000/ws/debug'

export default function App() {
  const [bugReport, setBugReport] = useState(PRESETS[0].text)
  const [events, setEvents] = useState([])
  const [running, setRunning] = useState(false)
  const [finalResult, setFinalResult] = useState(null)
  const wsRef = useRef(null)

  function runDebug() {
    setEvents([])
    setFinalResult(null)
    setRunning(true)

    const ws = new WebSocket(WS_URL)
    wsRef.current = ws

    ws.onopen = () => ws.send(JSON.stringify({ bug_report: bugReport }))

    ws.onmessage = (msg) => {
      const e = JSON.parse(msg.data)
      if (e.type === 'final') {
        setFinalResult(e.result)
        setRunning(false)
        ws.close()
      } else {
        setEvents((prev) => [...prev, e])
      }
    }

    ws.onerror = () => setRunning(false)
    ws.onclose = () => setRunning(false)
  }

  return (
    <div className="app">
      <h1>Multi-Agent Debug Assistant</h1>
      <p className="subtitle">Planner → Retriever → Diagnoser → Fixer → Verifier</p>

      <div className="presets">
        {PRESETS.map((p) => (
          <button
            key={p.label}
            className={bugReport === p.text ? 'preset active' : 'preset'}
            onClick={() => setBugReport(p.text)}
            disabled={running}
          >
            {p.label}
          </button>
        ))}
      </div>

      <textarea
        value={bugReport}
        onChange={(e) => setBugReport(e.target.value)}
        rows={3}
        disabled={running}
      />

      <button className="run-btn" onClick={runDebug} disabled={running}>
        {running ? 'Agents working…' : 'Submit Bug'}
      </button>

      <div className="timeline">
        {events.map((e, i) => (
          <div
            key={i}
            className="event"
            style={{ borderLeftColor: AGENT_COLORS[e.agent] || '#999' }}
          >
            <span
              className="agent-tag"
              style={{ background: AGENT_COLORS[e.agent] || '#999' }}
            >
              {e.agent}
            </span>

            {e.type === 'status' && <span>{e.message}</span>}
            {e.type === 'tool_call' && (
              <span>
                → calling tool <code>{e.tool}</code>
              </span>
            )}
            {e.type === 'tool_result' && (
              <span className="dim">
                ✓ {e.tool} returned {e.output?.length ?? 0} chars
              </span>
            )}
            {e.type === 'result' && <pre className="agent-output">{e.output}</pre>}
          </div>
        ))}
      </div>

      {finalResult && (
        <div className={`verdict ${finalResult.success ? 'pass' : 'fail'}`}>
          {finalResult.success ? '✅ Bug fixed and verified' : '❌ Fix could not be verified'}
        </div>
      )}
    </div>
  )
}
