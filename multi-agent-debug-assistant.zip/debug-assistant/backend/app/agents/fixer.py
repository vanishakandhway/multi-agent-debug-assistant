from ..config import SKILLS_DIR
from ..llm_client import run_agent

SKILL = (SKILLS_DIR / "fixer.md").read_text()


def fix(diagnosis: str, context: str, on_event=None) -> str:
    if on_event:
        on_event({"type": "status", "agent": "fixer", "message": "Writing a fix..."})
    msg = f"Diagnosis:\n{diagnosis}\n\nCode context:\n{context}"
    result = run_agent(
        SKILL,
        msg,
        allowed_tools=["read_file", "apply_patch"],
        on_event=lambda e: on_event and on_event({**e, "agent": "fixer"}),
    )
    if on_event:
        on_event({"type": "status", "agent": "fixer", "message": "Fix applied."})
    return result
