from ..config import SKILLS_DIR
from ..llm_client import run_agent

SKILL = (SKILLS_DIR / "diagnoser.md").read_text()


def diagnose(bug_report: str, context: str, on_event=None) -> str:
    if on_event:
        on_event({"type": "status", "agent": "diagnoser", "message": "Running tests and diagnosing root cause..."})
    msg = f"Bug report:\n{bug_report}\n\nCode context:\n{context}"
    result = run_agent(
        SKILL,
        msg,
        allowed_tools=["read_file", "run_tests"],
        on_event=lambda e: on_event and on_event({**e, "agent": "diagnoser"}),
    )
    if on_event:
        on_event({"type": "status", "agent": "diagnoser", "message": "Diagnosis complete."})
    return result
