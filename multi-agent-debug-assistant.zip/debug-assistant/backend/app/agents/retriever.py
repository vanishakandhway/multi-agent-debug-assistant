from ..config import SKILLS_DIR
from ..llm_client import run_agent

SKILL = (SKILLS_DIR / "retriever.md").read_text()


def retrieve(plan: str, on_event=None) -> str:
    if on_event:
        on_event({"type": "status", "agent": "retriever", "message": "Retrieving relevant code based on the plan..."})
    result = run_agent(
        SKILL,
        f"Investigation plan:\n{plan}",
        allowed_tools=["search_code", "read_file"],
        on_event=lambda e: on_event and on_event({**e, "agent": "retriever"}),
    )
    if on_event:
        on_event({"type": "status", "agent": "retriever", "message": "Context gathered."})
    return result
