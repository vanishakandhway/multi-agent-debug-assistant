from ..config import SKILLS_DIR
from ..llm_client import run_agent

SKILL = (SKILLS_DIR / "planner.md").read_text()


def plan(bug_report: str, on_event=None) -> str:
    if on_event:
        on_event({"type": "status", "agent": "planner", "message": "Analyzing bug report and forming an investigation plan..."})
    result = run_agent(
        SKILL,
        f"Bug report:\n{bug_report}",
        allowed_tools=["search_code"],
        on_event=lambda e: on_event and on_event({**e, "agent": "planner"}),
    )
    if on_event:
        on_event({"type": "status", "agent": "planner", "message": "Plan ready."})
    return result
