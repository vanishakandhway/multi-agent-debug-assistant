from ..config import SKILLS_DIR
from ..llm_client import run_agent

SKILL = (SKILLS_DIR / "verifier.md").read_text()


def verify(on_event=None) -> str:
    if on_event:
        on_event({"type": "status", "agent": "verifier", "message": "Verifying the fix..."})
    result = run_agent(
        SKILL,
        "Verify the fix that was just applied to the repository.",
        allowed_tools=["run_tests", "git_diff"],
        on_event=lambda e: on_event and on_event({**e, "agent": "verifier"}),
    )
    if on_event:
        on_event({"type": "status", "agent": "verifier", "message": "Verification complete."})
    return result
