import asyncio
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from .orchestrator import run_pipeline

app = FastAPI(title="Multi-Agent Debug Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.websocket("/ws/debug")
async def debug_ws(ws: WebSocket):
    """
    Client connects, sends {"bug_report": "..."}, and receives a stream of
    JSON events as each agent works (status updates, tool calls/results,
    per-agent outputs), ending with a {"type": "final", ...} event.
    """
    await ws.accept()
    try:
        data = await ws.receive_json()
    except WebSocketDisconnect:
        return

    bug_report = data.get("bug_report", "")
    loop = asyncio.get_event_loop()
    queue: asyncio.Queue = asyncio.Queue()

    def on_event(event: dict):
        # run_pipeline runs in a worker thread; hop back onto the event loop
        loop.call_soon_threadsafe(queue.put_nowait, event)

    async def run():
        result = await loop.run_in_executor(None, run_pipeline, bug_report, on_event)
        await queue.put({"type": "final", "result": result})

    task = asyncio.create_task(run())
    try:
        while True:
            event = await queue.get()
            await ws.send_json(event)
            if event.get("type") == "final":
                break
    except WebSocketDisconnect:
        pass
    finally:
        await task
        try:
            await ws.close()
        except RuntimeError:
            pass
