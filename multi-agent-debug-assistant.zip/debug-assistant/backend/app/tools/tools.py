"""
Allowlisted, sandboxed tools the agents are permitted to call.
No agent ever gets raw shell access -- every action goes through one of these
functions, and every path is validated to stay inside SANDBOX_DIR.

This module deliberately mirrors what an MCP tool server would expose
(name + schema + handler). Swapping this for a real MCP server later means
wrapping these same functions behind the MCP protocol -- the functions
themselves don't need to change.
"""
import subprocess
from pathlib import Path
from ..config import SANDBOX_DIR


def _resolve(path: str) -> Path:
    """Resolve a path and guarantee it stays inside the sandbox directory."""
    candidate = (SANDBOX_DIR / path).resolve()
    if candidate != SANDBOX_DIR and SANDBOX_DIR not in candidate.parents:
        raise PermissionError(f"Path '{path}' is outside the sandboxed repository.")
    return candidate


def read_file(path: str) -> str:
    p = _resolve(path)
    if not p.exists():
        return f"ERROR: file not found: {path}"
    return p.read_text()


def search_code(query: str) -> str:
    """Simple keyword search across .py files. Acts as MVP 'retrieval' before real vector RAG."""
    matches = []
    for f in sorted(SANDBOX_DIR.rglob("*.py")):
        try:
            lines = f.read_text().splitlines()
        except UnicodeDecodeError:
            continue
        for i, line in enumerate(lines, start=1):
            if query.lower() in line.lower():
                matches.append(f"{f.relative_to(SANDBOX_DIR)}:{i}: {line.strip()}")
    if not matches:
        return f"No matches for '{query}'."
    return "\n".join(matches[:40])


def run_tests(test_path: str = "") -> str:
    cmd = ["python", "-m", "pytest", "-v"]
    if test_path:
        cmd.append(test_path)
    result = subprocess.run(
        cmd, cwd=SANDBOX_DIR, capture_output=True, text=True, timeout=60
    )
    output = (result.stdout + "\n" + result.stderr).strip()
    return output[-4000:]  # keep it bounded


def git_diff() -> str:
    result = subprocess.run(
        ["git", "diff"], cwd=SANDBOX_DIR, capture_output=True, text=True
    )
    return result.stdout or "No changes."


def apply_patch(path: str, new_content: str) -> str:
    """Overwrite a .py file with full corrected content. This is the ONLY
    tool that can modify code, and only the Fixer agent is allowed to call it."""
    p = _resolve(path)
    if not p.exists():
        return f"ERROR: file not found: {path}"
    if p.suffix != ".py":
        return "ERROR: only .py files can be patched."
    p.write_text(new_content)
    return f"Patched {path} ({len(new_content)} chars written)."


TOOL_SCHEMAS = [
    {
        "name": "read_file",
        "description": "Read the full contents of a file inside the sandboxed repository. Path is relative to the repo root.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "search_code",
        "description": "Keyword search across all .py files in the sandboxed repo. Returns matching 'file:line: content' entries.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "run_tests",
        "description": "Run pytest inside the sandboxed repo. Optionally pass a specific test file path.",
        "input_schema": {
            "type": "object",
            "properties": {"test_path": {"type": "string"}},
            "required": [],
        },
    },
    {
        "name": "git_diff",
        "description": "Show the current uncommitted git diff of the sandboxed repo, to review exactly what changed.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "apply_patch",
        "description": "Overwrite a .py file inside the sandboxed repo with new full file contents. Used only to apply a fix.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "new_content": {"type": "string"},
            },
            "required": ["path", "new_content"],
        },
    },
]

DISPATCH = {
    "read_file": lambda i: read_file(i["path"]),
    "search_code": lambda i: search_code(i["query"]),
    "run_tests": lambda i: run_tests(i.get("test_path", "")),
    "git_diff": lambda i: git_diff(),
    "apply_patch": lambda i: apply_patch(i["path"], i["new_content"]),
}
