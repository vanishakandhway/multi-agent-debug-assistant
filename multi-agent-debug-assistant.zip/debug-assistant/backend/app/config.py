import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent   # backend/
SANDBOX_DIR = (BASE_DIR / "sample_repo").resolve()   # the ONLY dir agents may touch
SKILLS_DIR = Path(__file__).resolve().parent / "skills"

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
MODEL = os.environ.get("DEBUG_ASSISTANT_MODEL", "claude-sonnet-4-5")
MAX_TOOL_ITERATIONS = 8
