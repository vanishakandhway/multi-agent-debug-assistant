"""
Wraps a single agent 'turn': give it a system prompt (its skill file), a task,
and a whitelist of tools it's allowed to call. It loops -- calling tools and
feeding results back -- until the model returns a final text answer, or we hit
MAX_TOOL_ITERATIONS (a safety bound so a confused agent can't loop forever).
"""
import anthropic
from .config import ANTHROPIC_API_KEY, MODEL, MAX_TOOL_ITERATIONS
from .tools.tools import TOOL_SCHEMAS, DISPATCH

_client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)


def run_agent(system_prompt: str, user_message: str, allowed_tools: list, on_event=None) -> str:
    tools = [t for t in TOOL_SCHEMAS if t["name"] in allowed_tools]
    messages = [{"role": "user", "content": user_message}]

    for _ in range(MAX_TOOL_ITERATIONS):
        response = _client.messages.create(
            model=MODEL,
            max_tokens=2000,
            system=system_prompt,
            tools=tools,
            messages=messages,
        )
        messages.append({"role": "assistant", "content": response.content})

        tool_uses = [b for b in response.content if b.type == "tool_use"]
        if not tool_uses:
            return "".join(b.text for b in response.content if b.type == "text").strip()

        tool_results = []
        for tu in tool_uses:
            if on_event:
                on_event({"type": "tool_call", "tool": tu.name, "input": tu.input})
            try:
                output = DISPATCH[tu.name](tu.input)
            except Exception as e:  # never let a bad tool call crash the pipeline
                output = f"ERROR: {e}"
            if on_event:
                on_event({"type": "tool_result", "tool": tu.name, "output": str(output)[:500]})
            tool_results.append(
                {"type": "tool_result", "tool_use_id": tu.id, "content": str(output)}
            )
        messages.append({"role": "user", "content": tool_results})

    return "ERROR: agent exceeded max tool iterations without a final answer."
