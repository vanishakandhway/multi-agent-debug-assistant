"""
Chains the five agents into one pipeline: Planner -> Retriever -> Diagnoser
-> Fixer -> Verifier. Each agent's output becomes the next agent's input.
Emits events through on_event() as it goes, so the caller (the WebSocket
handler) can stream live progress to the frontend.
"""
from .agents import planner, retriever, diagnoser, fixer, verifier


def run_pipeline(bug_report: str, on_event=None) -> dict:
    def emit(e):
        if on_event:
            on_event(e)

    investigation_plan = planner.plan(bug_report, on_event)
    emit({"type": "result", "agent": "planner", "output": investigation_plan})

    context = retriever.retrieve(investigation_plan, on_event)
    emit({"type": "result", "agent": "retriever", "output": context})

    diagnosis = diagnoser.diagnose(bug_report, context, on_event)
    emit({"type": "result", "agent": "diagnoser", "output": diagnosis})

    applied_fix = fixer.fix(diagnosis, context, on_event)
    emit({"type": "result", "agent": "fixer", "output": applied_fix})

    verdict = verifier.verify(on_event)
    emit({"type": "result", "agent": "verifier", "output": verdict})

    success = verdict.strip().upper().startswith("PASS")
    emit({"type": "done", "success": success})

    return {
        "plan": investigation_plan,
        "context": context,
        "diagnosis": diagnosis,
        "fix": applied_fix,
        "verdict": verdict,
        "success": success,
    }
