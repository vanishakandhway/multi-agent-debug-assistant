from calc_utils import average, remove_duplicates, find_max_below


def test_average():
    assert average([1, 2, 3, 4]) == 2.5


def test_remove_duplicates():
    assert remove_duplicates([1, 2, 2, 3, 1]) == [1, 2, 3]


def test_find_max_below():
    assert find_max_below([1, 5, 9, 10], 10) == 9
