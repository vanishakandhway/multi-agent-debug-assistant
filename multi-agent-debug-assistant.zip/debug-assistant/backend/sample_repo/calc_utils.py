"""A tiny utility library with three seeded bugs for the Debug Assistant to find."""


def average(numbers):
    """Return the average of a list of numbers."""
    # BUG: integer (floor) division instead of true division -> wrong result, wrong type
    return sum(numbers) // len(numbers)


def remove_duplicates(items):
    """Remove duplicate items while preserving order."""
    seen = []
    result = []
    for item in items:
        # BUG: logic is inverted. It should keep the item when it has NOT
        # been seen before, and record it in `seen`. Right now it does the opposite.
        if item in seen:
            result.append(item)
    return result


def find_max_below(numbers, limit):
    """Return the maximum number that is strictly below `limit`."""
    # BUG: uses <= instead of <, so `limit` itself can be returned.
    candidates = [n for n in numbers if n <= limit]
    return max(candidates) if candidates else None
