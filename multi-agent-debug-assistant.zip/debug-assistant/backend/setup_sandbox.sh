#!/usr/bin/env bash
# Initializes git inside the sample repo so the Verifier agent's git_diff tool works.
set -e
cd "$(dirname "$0")/sample_repo"
if [ ! -d ".git" ]; then
  git init -q
  git add -A
  git -c user.email="bot@local" -c user.name="setup" commit -q -m "initial buggy repo"
  echo "Sandbox git repo initialized."
else
  echo "Sandbox already initialized."
fi
