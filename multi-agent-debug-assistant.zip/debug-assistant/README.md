# Multi-Agent Debug Assistant — MVP

A multi-agent system that investigates, diagnoses, fixes, and verifies bugs
in a small sample Python repo. Five specialized agents (Planner, Retriever,
Diagnoser, Fixer, Verifier) each run with a narrow role defined by a "skill
file", a restricted allowlist of tools, and hand off their output to the
next agent — coordinated by a lightweight custom orchestrator. A React
frontend shows the agents' progress live over a WebSocket.

## Architecture

```
React (frontend) --WebSocket--> FastAPI --> Orchestrator
                                              │
                    ┌──────────┬──────────┬───┴──────┬───────────┐
                 Planner   Retriever   Diagnoser    Fixer     Verifier
                (search)  (search,    (read_file,  (read_file, (run_tests,
                           read_file)  run_tests)   apply_patch) git_diff)
                                              │
                                    sandboxed sample_repo/
```

Each agent = one skill file (its system prompt + rules) + a whitelist of
tools it's allowed to call. No agent ever gets raw shell access — every
action goes through `app/tools/tools.py`, and every file path is validated
to stay inside `sample_repo/`.

## Why a custom orchestrator instead of Google ADK (for now)

This MVP uses direct Claude tool-calling with a simple Python orchestrator
instead of Google's Agent Development Kit, so you can run it immediately
with just an Anthropic API key — no Google Cloud/Gemini auth setup required
to get the core idea working. The agent/skill/tool boundaries are built to
match ADK's concepts (agent hierarchy, tool-calling, structured handoffs) on
purpose, so migrating the orchestrator to real ADK later is a swap, not a
rewrite.

## Why direct tool-calling instead of real MCP (for now)

The tools in `tools.py` are deliberately shaped like an MCP server would
expose them (name + schema + handler). This MVP calls them directly through
Claude's native tool-use rather than through the actual MCP protocol. Wiring
these same functions behind a real MCP server is a mechanical next step —
see Roadmap below.

## What's currently "RAG-lite"

`search_code` is a keyword/grep search, not vector-based retrieval. It gets
the pipeline working end-to-end first. Swapping it for real embeddings + a
vector DB (Qdrant/pgvector) is the first roadmap item, and only requires
changing the Retriever's tool, not the orchestration logic.

## Setup

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and set ANTHROPIC_API_KEY

./setup_sandbox.sh              # git-inits the sample repo (needed for git_diff)

uvicorn app.main:app --reload --port 8000
```

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173), pick one of the
three preset bugs (or write your own), and click **Submit Bug**. Watch the
five agents work in real time; the sample repo's bug gets diagnosed, fixed,
and verified against pytest.

### Resetting the sandbox after a run

Applying a fix modifies `sample_repo/calc_utils.py`. To reset it and try
again:

```bash
cd backend/sample_repo
git checkout -- calc_utils.py
```

## The seeded bugs (for your own testing/eval)

| Bug | Function | Symptom |
|---|---|---|
| 1 | `average()` | Integer division truncates the result |
| 2 | `remove_duplicates()` | Inverted logic — keeps only duplicates, drops uniques |
| 3 | `find_max_below()` | Off-by-one: `<=` instead of `<` |

All three currently fail `pytest` on a clean checkout — confirmed before
wiring the agents to them.

## Roadmap (build in this order — don't skip ahead)

1. **Real RAG** — replace `search_code` with embeddings + a vector DB
   (Qdrant/pgvector) so retrieval scales past a tiny sample repo.
2. **Real MCP** — expose `tools.py` behind an actual MCP server instead of
   direct function-calling, so the agent layer is protocol-agnostic.
3. ~~WebSocket live trace~~ — already in this MVP.
4. **Persistence** — PostgreSQL for run history, Redis for session/rate
   limiting.
5. **Containerize** — Docker Compose for local multi-service dev.
6. **Orchestrate for real** — Kubernetes deployment.
7. **CI/CD** — GitHub Actions: lint → test → build → deploy.
8. **Monitoring** — Prometheus/Grafana or structured logs; track tool-call
   success rate and per-agent latency.
9. **Support-mode skill files** — new skill files + tools
   (`check_order_status`, `create_ticket`) reusing this same orchestration
   engine, proving the architecture generalizes beyond debugging.
10. **Optional**: swap the custom orchestrator for real Google ADK.

## Known limitations (be ready to discuss these — they're real, not hidden)

- Single-pass pipeline: if Verifier reports FAIL, it currently does not loop
  back to the Fixer automatically (a good next feature).
- `search_code` is exact keyword match, not semantic — misses paraphrased
  queries.
- No retry/backoff on Anthropic API errors yet.
- No auth on the WebSocket endpoint — fine for local dev, not for anything
  public-facing yet.
